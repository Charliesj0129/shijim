from .shijim_core import *

__doc__ = shijim_core.__doc__
if hasattr(shijim_core, "__all__"):
    __all__ = shijim_core.__all__